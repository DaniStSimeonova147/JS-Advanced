﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=LAPTOP-SELJOP4P\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
